<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
     <p>我喜欢李白的诗句，尤其是那首《将进酒》</p>
    <hr>
   <Item :message="datas" :huijus="huijus" />
   <Submits ref="huijus" :add="add" :toName="toNames"/>


   <!-- <button @click="dealdata">模拟修改数据</button> -->
  </div>
</template>

<script>
import Item from './components/Item.vue'
import Submits from "./components/Submits"

export default {
  name: 'App',
  components: {
    Item,
    Submits
  },
  data(){
     return{
       datas:[
          {
            name:"张三",descreption:"我也非常喜欢",
            id:"001",
            flag:false,
            son:[
              {name:"小华",descreption:"你也在这个社区",id:"001",toName:"张三" },
              {name:"小红",descreption:"你怎么也在这个社区",id:"001",toName:"小华" }
              ]
          },

          // {name:"李四",descreption:"我喜欢杜甫的诗句",id:"002",son:[],flag:false},
          // {
          //   name:"王二",
          //   descreption:"我也非常喜欢",
          //   id:"003",
          //   son:[
          //       {name:"思思",descreption:"你也在这个社区",id:"001",toName:"王二" },
          //       {name:"小明",descreption:"你怎么也在这个社区",id:"002",toName:"思思" }
          //     ],
          //     flag:false
          // }
     ],
     ids:undefined,
     toNames:"",
     topathName:""
    }
  },
  mounted(){
    // this.$refs.huijus.$refs.huiju.focus();
  },
  methods:{
    add(obj){
     
      //在一级评论里追加一条二级评论 ids是点击一级评论回传的id值
      if(this.ids){
        console.log("进入");
        //往哪个一级评论加数据？ 根据回传的ids来判断
        this.datas=this.datas.map(value=>{
          if(value.id===this.ids){  //点击之后回传的id等于存在的id,就向这个数组加数据

            this.toNames=value.name; //

            obj["id"]=value.id
            obj["toName"]=this.topathName  //代表二级评论的目标是当前的一级评论

            delete obj.son;
            value.son.push(obj)

            this.ids=undefined;
            return {
                  name:value.name,
                  descreption:value.descreption,
                  id:value.id,
                  son:value.son,
                  flag:false
                }

            }
            else{
                return {
                  name:value.name,
                  descreption:value.descreption,
                  id:value.id,
                  son:value.son,
                  flag:false
                }

            }
        })

      }
       //增加一条一级评论
      //如果ids没有回传，即是一级评论，否者是二级
      else{
        obj["toName"]=this.topathName  //代表二级评论的目标是当前的一级评论
        this.datas.unshift(obj)
      }
    },


    //功能：汇聚输入框焦点，并显示回复谁
     huijus(ids,name){
           this.$refs.huijus.$refs.huiju.focus();
           //console.log("回传的ID=="+ids);
           this.ids=ids;
          
          //name如果有值就是二级之间的评论
            if(name){ 
              //目的：是在输入框提示  "回复"：xxx某人
              this.topathName=name;
               this.datas.map((value)=>{
                    if(value.id==ids){
                        this.toNames="回复："+name;
                       
                    }
                  })
            }

            else{
                 this.topathName="name";
                    this.datas.map((value)=>{
                    if(value.id==ids){
                        this.toNames="回复："+value.name;
                    }
                  })
            }
            
        },

        cleartoName(data){
          console.log("监听OK")
          this.toNames=""
          console.log(data)
        }
  },
  mounted(){
    this.$refs.huijus.$on("cleartoName",this.cleartoName)
  }
}
</script>

<style>
</style>
