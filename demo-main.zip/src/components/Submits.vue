<template>
    <div>
            <form action="">
            <textarea ref="huiju"  name="" id="descrption" :placeholder="toName||'请输入你想说的'"   v-model="text"></textarea>
            </form>
        <button @click="submits">发表评论</button>
        <!-- <button>聚焦</button> -->
    </div>
</template>

<script>

export default {
    name:"Submits",
    data(){
        return{
            text:""
        }
    },
    props:{
        add:{
            type:Function
        },
        toName:{
            type:String,
            default:"请输入你想说的"
        }
    },
    methods:{
        submits(){

            //做判断，flag思true 则加入子数组
           this.add({
               name:"辛弃疾",
               descreption:this.text,
               id:"002",
               son:[],
               })

           this.text=""

           this.$emit("cleartoName","xshhsaisa")
         

        }
        
    },

}
</script>

<style>

</style>