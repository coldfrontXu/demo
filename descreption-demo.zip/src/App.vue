<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
     <p>我喜欢李白的诗句，尤其是那首《将进酒》</p>
    <hr>
   <Item :message="datas" :huijus="huijus" :addSon="addSon"/>
   <Submits ref="huiju" :add="add"/>
  </div>
</template>

<script>
import Item from './components/Item.vue'
import Submits from "./components/Submits"

export default {
  name: 'App',
  components: {
    Item,
    Submits
  },
  data(){
     return{
       datas:[
          {name:"张三",descreption:"我也非常喜欢",id:"001",flag:false,
          son:[
             {name:"小华",descreption:"你也在这个社区",id:"001",toName:"张三" },
            {name:"小红",descreption:"你怎么也在这个社区",id:"002",toName:"小华" }
          ]},

          {name:"李四",descreption:"我喜欢杜甫的诗句",id:"002",son:[],flag:false},
          {name:"王二",descreption:"我也非常喜欢",id:"003",
          son:[
              {name:"思思",descreption:"你也在这个社区",id:"001",toName:"王二" },
              {name:"小明",descreption:"你怎么也在这个社区",id:"002",toName:"思思" }
            ],flag:false
          }
     ]
    }
  },
  methods:{
    add(obj){
      this.datas=this.datas.map((value)=>{
        if(value.flag){
          value.son.push(obj)
        }
        else{
           this.datas.unshift(obj);
        }
      })

    },
      huijus(){
           this.$refs.huiju.$refs.huiju.focus();
        },

      addSon(value,text){
        this.datas=this.datas.map((value,index)=>{
          if(value.id==value){
            console.log("OK");
            value.son.push({name:"项羽",descreption:"text",toName:"张三"})
          }
        })

      },
      dealdata(){
      //  this.data = this.datas.map((value)=>{

      //   })
      }

        // select(){

        // }
  },
  mounted(){
         
  }
}
</script>

<style>

</style>
