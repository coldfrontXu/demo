<template>
    <div>
            <form action="">
            <textarea ref="huiju"  name="" id="descrption" cols="30" rows="10" placeholder="请输入你想评论的"   v-model="text"></textarea>
            </form>
        <button @click="submits">发表评论</button>
        <button>聚焦</button>
    </div>
</template>

<script>

export default {
    name:"Submits",
    data(){
        return{
            text:""
        }
    },
    props:{
        add:{
            type:Function
        }
    },
    methods:{
        submits(){
            //做判断，flag思true 则加入子数组

        console.log(this.text);
           console.log(this.add)
           this.add({name:"辛弃疾",descreption:this.text,id:"001",son:[]})
           this.text=""

        }
      
        

    }
}
</script>

<style>

</style>