<template>
  <div class="hello" >
     <div class="descreption" v-for="(value,index) in message" :key="index">
            <p @click="getobj(null,$event)" >
              <span style="color: tomato;" >{{value.name}}：</span> <span>&nbsp;&nbsp;{{value.descreption}}</span>
            </p>
            <div v-if="value.son.length>0?true:false" style="margin-left:10px"> 
                <p v-for="(values,indexs) in value.son" :key="indexs">
                 <span style="color: tomato;"> &nbsp;&nbsp;&nbsp;{{values.name}}&nbsp;回复&nbsp;{{values.toName}}：</span><span>&nbsp;&nbsp;{{values.descreption}}</span>
                </p>
            </div>
      </div>

  </div>
</template>

<script>
export default {
  name: 'Item',
  props:["message","huijus","addSon"],
  methods:{
    getobj(value,event){
      let end=event.target.innerText.indexOf("：");
      // console.log(end)
      console.dir(event.target.innerText.substring(0,end));
      console.dir(event.target);
      //调用父级的聚焦函数
      this.huijus();










    }
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  div{
          margin:20px 0;
      }
</style>
